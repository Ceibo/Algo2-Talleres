#ifndef CONJUNTO_HPP_
#define CONJUNTO_HPP_

#include <iostream>
using namespace std;

template <class T>
class Conjunto
{
	public:

		// Constructor. Genera un conjunto vacío.
		Conjunto();

		// Destructor. Debe dejar limpia la memoria.
		~Conjunto();

		// Inserta un elemento en el conjunto. Si éste ya existe,
		// el conjunto no se modifica.
		void insertar(const T&);

		// Decide si un elemento pertenece al conjunto o no.
		bool pertenece(const T&) const;

		// borra un elemento del conjunto. Si éste no existe,
		// el conjunto no se modifica.
		void remover(const T&);

		// devuelve el mínimo elemento del conjunto según <.
		const T& minimo() const;

		// devuelve el máximo elemento del conjunto según <.
		const T& maximo() const;

		// devuelve la cantidad de elementos que tiene el conjunto.
		unsigned int cardinal() const;

		// muestra el conjunto.
		void mostrar(std::ostream&) const;

		friend ostream& operator<<(ostream& os, const Conjunto<T> &c) {
			c.mostrar(os);
			return os;
		}

	private:

		// la representación de un nodo interno.
		struct Nodo
		{
			// el constructor, toma el elemento al que representa el nodo.
			Nodo(const T& v);
			// el elemento al que representa el nodo.
			T valor;
			// puntero a la raíz del subárbol izq.
			Nodo* izq;
			// puntero a la raíz del subárbol der.
			Nodo* der; 
		};

		// puntero a la raíz de nuestro árbol.
		Nodo* raiz_;

	// funciones auxiliares

		

};

template <class T>
Conjunto<T>::Nodo::Nodo(const T& v)
	 : valor(v), izq(NULL), der(NULL)
{}

template <class T>
Conjunto<T>::Conjunto() : raiz_(NULL)
{}

template <class T>
Conjunto<T>::~Conjunto()
{ 
}

template <class T>
bool Conjunto<T>::pertenece(const T& clave) const
{
	return false;
}

template <class T>
void Conjunto<T>::insertar(const T& clave)
{
}

template <class T>
unsigned int Conjunto<T>::cardinal() const
{
	return 0;
}

template <class T>
void Conjunto<T>::remover(const T& clave)
{
}

template <class T>
const T&  Conjunto<T>::minimo() const
{
	T t;
	return t;
}

template <class T>
const T&  Conjunto<T>::maximo() const
{
	T t;
	return t;
}

template <class T>
void Conjunto<T>::mostrar(std::ostream& os) const {

}

#endif // CONJUNTO_HPP_
