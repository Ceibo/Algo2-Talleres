#include <iostream>
#include "mini_test.h"

#include "Conjunto.hpp"

void test_insertar() {
	Conjunto<int> c;
	c.insertar(42);
	ASSERT( c.pertenece(42) );
}

int main() {

	RUN_TEST(test_insertar);
	return 0;
}
